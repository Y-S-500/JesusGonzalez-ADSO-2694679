function navbarConten(){
return `
<div class="nav justify-content-center">
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" aria-current="page" href="#">Opciones</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="departamento.html">Departamento</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="continente.html">Continente</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="ciudad.html">Ciudad</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="pais.html">Pais</a>
      </li>  
    <li class="nav-item">
      <a class="nav-link disabled" aria-disabled="true">Opciones</a>
    </li>
  </ul>
</div>`


}