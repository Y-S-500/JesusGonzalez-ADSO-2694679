package com.sena.continentes.IRepository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.continentes.Entity.Continentes;

public interface IcontinentesRepository extends JpaRepository<Continentes, Long>{
    
}





