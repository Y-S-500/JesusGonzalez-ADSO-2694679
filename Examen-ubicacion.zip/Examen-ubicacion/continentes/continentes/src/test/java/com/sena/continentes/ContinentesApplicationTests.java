package com.sena.continentes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContinentesApplicationTests {

	@Test
	void contextLoads() {
	}

}
