// Manejar el evento de envío del formulario
document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('.needs-validation');
    form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
            event.preventDefault(); // Evitar el envío del formulario si hay campos inválidos
            event.stopPropagation();
        }

        form.classList.add('was-validated'); // Mostrar los mensajes de validación

        // Aquí puedes agregar tu propia lógica de validación personalizada si es necesario
    });
});
